# Cosmic Foundry Bot (Option B)
Reward-based Telegram game. Currency: Crystal

## Quick start (Railway)
1. Upload this repo to GitHub.
2. Connect the repo to Railway and deploy.
3. In Railway Variables add:
   - TELEGRAM_TOKEN (your bot token)
   - REWARD_POINTS_START (e.g. 100)
   - REWARD_POINTS_DAILY (e.g. 10)
4. Deploy and check logs. Use Telegram to message your bot:
   - /start
   - /mine
   - /balance
   - /daily

## Notes
- Messages are simple text-only.
- This is a minimal starter. Customize game logic and security before public use.
